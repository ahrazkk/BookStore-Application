
package coe528.group.project;

/**
 *
 * @author tahag
 */
public abstract class State {
    
    protected abstract void setGold(Customer C);
    protected abstract void setSilver(Customer C);
    
}
 


